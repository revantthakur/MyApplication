import React from "react";
const SalesTeam = () => {
  return <div className="SalesTeam">SalesTeam</div>;
};

export default SalesTeam;
