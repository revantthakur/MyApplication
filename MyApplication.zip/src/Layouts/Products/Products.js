import React from "react";
const Products = () => {
  return <div className="Products">Products</div>;
};

export default Products;
