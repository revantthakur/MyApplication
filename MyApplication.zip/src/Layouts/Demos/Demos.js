import React from "react";
const Demos = () => {
  return <div className="Demos">Demos</div>;
};

export default Demos;
