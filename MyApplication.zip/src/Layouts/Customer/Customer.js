import React from "react";
const Customer = () => {
  return <div className="Customer">Customer</div>;
};

export default Customer;
