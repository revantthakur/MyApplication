import React from "react";
const DemoScripts = () => {
  return <div className="DemoScripts">DemoScripts</div>;
};

export default DemoScripts;
